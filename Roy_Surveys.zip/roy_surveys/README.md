# Roy Surveys

A mobile-friendly front-end prototype for a survey-reward website.

## Included
- Registration and login using browser localStorage
- Dashboard
- Six sample surveys
- Hakeems virtual coin balance
- Survey completion history
- Responsive mobile design

## Important
This is a demo/prototype. Login data is stored in the browser and is NOT suitable for a real production website.

For a real public service, replace the localStorage authentication with a secure backend/database, password hashing, server-side sessions, anti-fraud controls, survey management, and a proper rewards/redemption system.

## Run
Open `index.html` in a modern browser, or upload the folder to a static web host.
