const surveys=[
{id:1,title:"Your Daily Routine",time:"1–2 min",reward:20,icon:"☀️",questions:[
["How do you usually start your day?",["Breakfast","Tea/coffee","Exercise","Straight to work/school"]],
["How often do you use social media daily?",["Less than 1 hour","1–3 hours","3–5 hours","More than 5 hours"]]]},
{id:2,title:"Shopping Habits",time:"2–3 min",reward:35,icon:"🛍️",questions:[
["Where do you shop most often?",["Supermarket","Local shop","Online","Market"]],
["What matters most when buying something?",["Price","Quality","Brand","Convenience"]]]},
{id:3,title:"Entertainment",time:"2 min",reward:25,icon:"🎧",questions:[
["What do you enjoy most in your free time?",["Music","Movies","Gaming","Sports"]],
["How often do you watch short videos?",["Never","Sometimes","Daily","Several times a day"]]]},
{id:4,title:"Technology",time:"3 min",reward:50,icon:"📱",questions:[
["Which device do you use most?",["Phone","Laptop","Tablet","Desktop"]],
["What is most important in a phone?",["Battery","Camera","Performance","Price"]]]},
{id:5,title:"Food Preferences",time:"2 min",reward:30,icon:"🍽️",questions:[
["Which meal is most important to you?",["Breakfast","Lunch","Dinner","Snacks"]],
["How often do you try new foods?",["Rarely","Sometimes","Often","Very often"]]]},
{id:6,title:"Community Poll",time:"1 min",reward:15,icon:"📊",questions:[
["How often do you answer online polls?",["Never","Rarely","Sometimes","Often"]],
["Would you recommend surveys to friends?",["Yes","Maybe","No"]]]}
];

let mode="login", current=null;
const $=id=>document.getElementById(id);
function getUsers(){return JSON.parse(localStorage.getItem("roy_users")||"{}")}
function saveUsers(u){localStorage.setItem("roy_users",JSON.stringify(u))}
function getSession(){return localStorage.getItem("roy_session")}
function showLanding(){["auth","dashboard","surveyView"].forEach(x=>$(x).classList.add("hidden"));$("landing").classList.remove("hidden");renderUserArea()}
function showAuth(m){mode=m;$("landing").classList.add("hidden");$("dashboard").classList.add("hidden");$("surveyView").classList.add("hidden");$("auth").classList.remove("hidden");$("authTitle").textContent=m==="login"?"Welcome back":"Create your account";$("authSubtitle").textContent=m==="login"?"Log in to continue earning Hakeems.":"Join Roy Surveys and start earning Hakeems.";$("nameField").classList.toggle("hidden",m==="login");$("username").required=m==="register";$("authButton").textContent=m==="login"?"Log in":"Create account";$("switchText").innerHTML=m==="login"?`Don't have an account? <a onclick="showAuth('register')">Create one</a>`:`Already have an account? <a onclick="showAuth('login')">Log in</a>`}
function handleAuth(e){e.preventDefault();let users=getUsers(),email=$("email").value.trim().toLowerCase(),pw=$("password").value;if(mode==="register"){if(users[email])return alert("An account with this email already exists.");users[email]={username:$("username").value.trim(),password:pw,balance:0,completed:[],activity:[]};saveUsers(users);localStorage.setItem("roy_session",email);showDashboard()}else{if(!users[email]||users[email].password!==pw)return alert("Incorrect email or password.");localStorage.setItem("roy_session",email);showDashboard()}}
function logout(){localStorage.removeItem("roy_session");showLanding()}
function renderUserArea(){let email=getSession();$("userArea").innerHTML=email?`<button class="secondary" onclick="showDashboard()">Dashboard</button>`:""}
function showDashboard(){let email=getSession();if(!email)return showAuth("login");let u=getUsers()[email];$("landing").classList.add("hidden");$("auth").classList.add("hidden");$("surveyView").classList.add("hidden");$("dashboard").classList.remove("hidden");$("dashName").textContent=u.username;$("balance").textContent=u.balance;$("completed").textContent=u.completed.length;$("available").textContent=surveys.filter(s=>!u.completed.includes(s.id)).length;renderSurveys(u);renderActivity(u);renderUserArea()}
function renderSurveys(u){$("surveys").innerHTML=surveys.filter(s=>!u.completed.includes(s.id)).map(s=>`<article class="survey"><div>${s.icon}</div><h3>${s.title}</h3><p>Simple questions · ${s.time}</p><div class="reward">+${s.reward} Hakeems</div><button class="primary" onclick="startSurvey(${s.id})">Take survey</button></article>`).join("")||`<div class="survey"><h3>🎉 All done!</h3><p>You have completed every demo survey currently available.</p></div>`}
function renderActivity(u){$("activity").innerHTML=u.activity.length?u.activity.slice().reverse().map(a=>`<div class="activity-row"><span>${a.title}</span><strong>+${a.reward} HKM</strong></div>`).join(""):`<div class="activity-row"><span>No activity yet</span><small>Complete a survey to see it here.</small></div>`}
function startSurvey(id){current=surveys.find(s=>s.id===id);$("dashboard").classList.add("hidden");$("surveyView").classList.remove("hidden");$("surveyContent").innerHTML=`<p class="eyebrow">${current.icon} SURVEY</p><h2>${current.title}</h2><p>${current.time} · <span class="reward">+${current.reward} Hakeems</span></p><form onsubmit="submitSurvey(event)">${current.questions.map((q,i)=>`<div class="question"><p>${i+1}. ${q[0]}</p><div class="options">${q[1].map(o=>`<label class="option"><input type="radio" name="q${i}" value="${o}" required> ${o}</label>`).join("")}</div></div>`).join("")}<button class="primary full">Submit survey & earn ${current.reward} Hakeems</button></form>`}
function submitSurvey(e){e.preventDefault();let email=getSession(),users=getUsers(),u=users[email];u.balance+=current.reward;u.completed.push(current.id);u.activity.push({title:current.title,reward:current.reward});users[email]=u;saveUsers(users);alert(`Survey completed! You earned ${current.reward} Hakeems.`);showDashboard()}
renderUserArea(); if(getSession()) showDashboard(); else showLanding();
